// Chapter Number 1
//alert("Welcome to our Website!")
//alert("Error! Please Enter a valid password.")
//alert("Welcome to JS Land... \n Happy Coding!" )
// alert("Welcome to JS Land..." )
// alert("Happy Coding! \n Prevent this page from creating additional dailogues" )

// I went in the inspect tool to the console and typed this code over there 
// so i found the same result from here to there now i can run JS by both. 
//  alert("Hello.. I can run JS through my web browser's Console " )

/*<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment of JS</title>
    <script src="app.js"></script>
</head>
<body>
    
</body>
</html>
This is the way that i can connenct my JS file to html page in the Head tag by typing Script Tag below title tag
after that i put an attribute of SRC to link my JS file to HTML.*/ 

//============== Chapter 1 Got Completed ================>

// Chapter Number 2

//var username;
// var fullName = "Sanjay Kumar";
// var message = "Hello World";
// alert(message);

// var fullName = " Pizza \n Pizz \n Piz \n Pi \n P";
// alert(fullName);

// var fullName = "John Dave";
// var dob = 20 + "Years Old";
// var course = "Certified Mobile Application Development";
// alert(fullName);
// alert(dob);
// alert(course);

// var email = "khatrisanjay095@gmail.com";
// var intro = "My email address is ";
// alert(intro + email);

// var book = "A smarter way to learn JavaScript";
//  var intro = "I'm trying to learn from the Book  ";
//  alert(intro + book);

// var content = "Yeah! I can write content through HTML in JavaScript ";
// document.write(content)

// var end = "<----------------$&*&$---------------> ";
// alert(end);

//chapter 2 got ended successfully

//starting chapter 3

//  var age = "I'm " + 20 + " Years Old";
// alert(age);

// var track = "You've visited this site " + 20 +  " Times";
// alert(track);

// var birthYear = "My birth year is " + 2001 + "<br>  Data type of declared number is varaible";
// document.write(birthYear);

// var visitorName = "JOHN DOE "; 
// var product = "ordered " + "<strong> 5 </strong>";
// var quantity = "<b> T-Shirt</b>(s) on XYZ Clothing store.";
//  document.write(visitorName + product + quantity);

//chapter 3 got ended 

//starting chapter 4 

 //var name = "JOHN DOE " , fatherName = "Doe Johnson" , age = 23; 

 //5 Illegal Names
//  var Username = "A ";
//  var USERNAME = "B ";
//  var -username = "C ";
//  var @username = "D ";
//  var 23username = "E ";

//5 Legal Names
//  var name23 = "F ";
//  var name = "G ";
//  var $name = "H ";
//  var userName = "I ";
//  var nam23e = "J ";
//  console.log(name23 + name + $name + userName + nam23e);
 
// var A = "<h1> Rules For Naming JS Variables </h1></br></br>";
// var B = "Varaibles names can only contains numbers, $ and _. For Example: $my_1stVaraible </br>";
// var C = "Varaibles must begin with a letter,$ and _. For Example: $name, _name or name </br>";
// var D = "Varaibles names case sensitive </br>";
// var E = "Varaibles names should not be JS keywords </br>";
// document.write(A + B + C + D +E)

//chapter 4 got ended 

//starting chapter 5

//   var a = 7;
//   var b = 8;
//   var add = a + b;

//   document.write(add);

//   var a = 7;
//   var b = 8;
//   var sub = a - b;

//   document.write(sub);
  
//   var a = 7;
//   var b = 8;
//   var multi = a * b;

//   document.write(multi);
  
//   var a = 7;
//   var b = 8;
//   var div = a / b;

//   document.write(div);

// var a = 5;
//   var b = 27;
//   var mod = b % a;

//   document.write(mod);

// var A = "Value after variable declaration is undefined <br>"
// var B = "Initial Value : 5 <br>"
// var C = "Value after increment is:6 <br>"
// var D = "Value after addition is:13 <br>"
// var E = "Value after decrement is:12 <br>"
// var F = "The remainder is:0 <br>"
// document.write(A + B + C + D + E + F);

// var a = 600
// var b = 5
// var multi = a * b

// document.write("Total cost to buy " , b , " Tickets to a movie is " , multi , "PKR");

//  var a = 2 + " x " + 1 + " = " + 2 + "<br>"
//  var b = 2 + " x " + 2 + " = " + 4 + "<br>"
//  var c = 2 + " x " + 3 + " = " + 6 + "<br>"
//  var d = 2 + " x " + 4 + " = " + 8 + "<br>"
//  var e = 2 + " x " + 5 + " = " + 10 + "<br>"
//  var f = 2 + " x " + 6 + " = " + 12 + "<br>"
//  var g = 2 + " x " + 7 + " = " + 14 + "<br>"
//  var h = 2 + " x " + 8 + " = " + 16 + "<br>"
//  var i = 2 + " x " + 9 + " = " + 18 + "<br>"
//  var j = 2 + " x " + 10 + " = " + 20 + "<br>"
//  document.write(a + b + c + d + e + f + g + h + i + j);
